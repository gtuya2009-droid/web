# 🧶 Yarn & Grace — Handcrafted Crochet Website

A cozy, colorful crochet website built with HTML, CSS and JavaScript.

## Pages / Sections
- 🏠 Homepage with hero banner
- 🛍️ Shop gallery with product cards
- 📖 Tutorials & blog posts
- 💰 Pricing & custom orders
- 📬 Contact form

## How to view locally
Just open `index.html` in your browser — no setup needed!

## How to publish with GitHub Pages
1. Push this folder to a GitHub repository
2. Go to Settings → Pages
3. Set source to **main branch / root**
4. Your site will be live at `https://yourusername.github.io/your-repo-name`

## Adding photos
Drop your image files in this folder and update the `src=""` in `index.html` to match your filenames.
